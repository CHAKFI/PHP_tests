<?php
####################################################################################################
## File : users.queries.php
## Author : Nils Laumaill�
## Description : File contains queries for ajax
## 
## DON'T CHANGE !!!
## 
####################################################################################################

session_start();
include('../includes/settings.php');  
header("Content-type: text/html; charset=".$k['charset']); 

//Connect to mysql server
require_once("class.database.php"); 
$db = new Database($server, $user, $pass, $database, $pre);
$db->connect(); 

// Construction de la requ�te en fonction du type de valeur
if ( !empty($_POST['type']) ){
    switch($_POST['type'])
    {
        case "groupes_visibles":
        case "groupes_interdits":
            $val = explode(';',$_POST['valeur']);
            $valeur = $_POST['valeur'];
            //Check if id folder is already stored
            $data = $db->fetch_row("SELECT ".$_POST['type']." FROM ".$pre."users WHERE id = ".$val[0]);
            $new_groupes = $data[0];
            if ( !empty($data[0]) ){
                $groupes = explode(';',$data[0]);
                if ( in_array($val[1],$groupes ) ) $new_groupes = str_replace($val[1],"",$new_groupes);
                else $new_groupes .= ";".$val[1];
            }else{
                $new_groupes = $val[1];
            }
            while ( substr_count($new_groupes,";;") > 0 ) 
                $new_groupes = str_replace(";;",";",$new_groupes);
            
            //Store id DB
            $db->query_update(
                "users",
                array(
                    $_POST['type'] => $new_groupes
                ),
                "id = ".$val[0]
            );
        
        break;
        
        case "fonction":
            $val = explode(';',$_POST['valeur']);
            $valeur = $_POST['valeur'];
            //v�rifier si l'id est d�j� pr�sent
            $data = $db->fetch_row("SELECT fonction_id FROM ".$pre."users WHERE id = $val[0]");
            $new_fonctions = $data[0];
            if ( !empty($data[0]) ){
                $fonctions = explode(';',$data[0]);
                if ( in_array($val[1],$fonctions ) ) $new_fonctions = str_replace($val[1],"",$new_fonctions);
                else if ( !empty($new_fonctions) )
                    $new_fonctions .= ";".$val[1];
                else
                    $new_fonctions = ";".$val[1];
            }else{
                $new_fonctions = $val[1];
            }
            while ( substr_count($new_fonctions,";;") > 0 ) 
                $new_fonctions = str_replace(";;",";",$new_fonctions);
                
             //Store id DB
            $db->query_update(
                "users",
                array(
                    'fonction_id' => $new_fonctions
                ),
                "id = ".$val[0]
            );        
        break;   
        
        ## ADD NEW USER ##
        case "add_new_user":
            //Add user in DB
            $new_id = $db->query_insert(
                "users",
                array(
                    'login' => mysql_real_escape_string(stripslashes($_POST['login'])),
                    'pw' => mysql_real_escape_string(stripslashes(md5($_POST['pw']))),
                    'email' => $_POST['email'],
                    'admin' => $_POST['admin']=="true" ? '1' : '0',
                    'gestionnaire' => $_POST['manager']=="true" ? '1' : '0',
                    'personal_folder' => $_POST['personal_folder']=="true" ? '1' : '0'
                )
            );
            
            
            //Create personnal folder
            if ( $_POST['personal_folder']=="true" )
                $db->query_insert(
                    "nested_tree",
                    array(
                        'parent_id' => '0',
                        'title' => $new_id,
                        'bloquer_creation' => '0',
                        'bloquer_modification' => '0',
                        'personal_folder' => '1'
                    )
                );
            
            //reload page
            echo 'document.form_utilisateurs.submit();';
        break;
        
        ## DELETE USER ##
        case "supprimer_user":
            $db->query("DELETE FROM ".$pre."users WHERE id = ".$_POST['id']);
            //reload page
            echo 'document.form_utilisateurs.submit();';
        break;
        
        ## UPDATE PASSWORD OF USER ##
        case "modif_mdp_user":
           $db->query_update(
                "users",
                array(
                    'pw' => mysql_real_escape_string(stripslashes(md5($_POST['newmdp'])))
                ),
                "id = ".$_POST['id']
            );
            
            echo '$("#div_loading").hide()';  //hide loading div
        break;
        
        ## UPDATE EMAIL OF USER ##
        case "modif_mail_user":
           $db->query_update(
                "users",
                array(
                    'email' => $_POST['newemail']
                ),
                "id = ".$_POST['id']
            );
        break;
        
        ## UPDATE MANAGER RIGHTS FOR USER ##
        case "modif_droit_gest_groupes_user":
           $db->query_update(
                "users",
                array(
                    'gestionnaire' => $_POST['gest_groupes']
                ),
                "id = ".$_POST['id']
            );
        break;
        
        ## UPDATE ADMIN RIGHTS FOR USER ##
        case "modif_droit_admin_user":
           $db->query_update(
                "users",
                array(
                    'admin' => $_POST['admin']
                ),
                "id = ".$_POST['id']
            );
        break;
        
        ## UPDATE PERSONNAL FOLDER FOR USER ##
        case "modif_personal_folder_user":
           $db->query_update(
                "users",
                array(
                    'personal_folder' => $_POST['pers_fld']
                ),
                "id = ".$_POST['id']
            );
        break;
        
        //CHANGE USER FUNCTIONS
        case "open_div_functions";
            $text = "";
            //Refresh list of existing functions
            $data_user = $db->fetch_row("SELECT fonction_id FROM ".$pre."users WHERE id = ".$_POST['id']);
            $users_functions = explode(';',$data_user[0]);
            
            $rows = $db->fetch_all_array("SELECT id,title FROM ".$pre."functions");
            foreach( $rows as $reccord ){
                $text .= '<input type=\"checkbox\" id=\"cb_change_function-'.$reccord['id'].'\"';
                if ( in_array($reccord['id'],$users_functions) )  $text .= ' checked';
                $text .= '>&nbsp;'.$reccord['title'].'<br />';
            }
            
            //update page
            echo 'document.getElementById("change_user_functions_list").innerHTML = "'.$text.'";';
            echo 'document.getElementById("selected_user").value = "'.$_POST['id'].'";';
                        
            //display dialogbox
            echo '$("#change_user_functions").dialog("open");';
            echo '$("#div_loading").hide()';  //hide loading div
        break;
        
        case "change_user_functions";
            //save data
            $db->query_update(
                "users",
                array(
                    'fonction_id' => $_POST['list']
                ),
                "id = ".$_POST['id']
            );
            
            //display information
            $text = "";
            $val = str_replace(';',',',$_POST['list']);
            //Check if POST is empty
            if ( !empty($val) ){
                $rows = $db->fetch_all_array("SELECT title FROM ".$pre."functions WHERE id IN (".$val.")");
                foreach( $rows as $reccord ){
                    $text .= '<img src=\"includes/images/arrow-000-small.png\" />'.$reccord['title']."<br />";
                }                
            }else
                $text = '<span style=\"text-align:center\"><img src=\"includes/images/error.png\" /></span>';
            echo 'document.getElementById("list_function_user_'.$_POST['id'].'").innerHTML = "'.$text.'";';
        break;
        
        //CHANGE AUTHORIZED GROUPS
        case "open_div_autgroups";
            $text = "";
            //Refresh list of existing functions
            $data_user = $db->fetch_row("SELECT groupes_visibles FROM ".$pre."users WHERE id = ".$_POST['id']);
            $user = explode(';',$data_user[0]);
            
            require_once ("NestedTree.class.php");
            $tree = new NestedTree($pre.'nested_tree', 'id', 'parent_id', 'title');
            $tree_desc = $tree->getDescendants();
            foreach($tree_desc as $t){
                if ( in_array($t->id,$_SESSION['groupes_visibles']) ) {
                    $text .= '<input type=\"checkbox\" id=\"cb_change_autgroup-'.$t->id.'\"';
                    $ident="";
                    for($y=1;$y<$t->nlevel;$y++) $ident .= "&nbsp;&nbsp;";
                    if ( in_array($t->id,$user) ) $text .= ' checked';
                    $text .= '>&nbsp;'.$ident.$t->title.'<br />';
                    $prev_level = $t->nlevel;
                }
            }
            
            echo 'document.getElementById("change_user_autgroups_list").innerHTML = "'.$text.'";';
            echo 'document.getElementById("selected_user").value = "'.$_POST['id'].'";';
                        
            //display dialogbox
            echo '$("#change_user_autgroups").dialog("open");';
            echo '$("#div_loading").hide()';  //hide loading div
        break;
        
        case "change_user_autgroups";
            //save data
            $db->query_update(
                "users",
                array(
                    'groupes_visibles' => $_POST['list']
                ),
                "id = ".$_POST['id']
            );
            
            //display information
            $text = "";
            $val = str_replace(';',',',$_POST['list']);
            //Check if POST is empty
            if ( !empty($_POST['list']) ){
                $rows = $db->fetch_all_array("SELECT title,nlevel FROM ".$pre."nested_tree WHERE id IN (".$val.")");
                foreach( $rows as $reccord ){
                    $ident="";
                    for($y=1;$y<$reccord['nlevel'];$y++) $ident .= "&nbsp;&nbsp;";
                    $text .= '<img src=\"includes/images/arrow-000-small.png\" />'.$ident.$reccord['title']."<br />";
                }
            }
            echo 'document.getElementById("list_autgroups_user_'.$_POST['id'].'").innerHTML = "'.$text.'";';
        break;
        
        //CHANGE FORBIDDEN GROUPS
        case "open_div_forgroups";
            $text = "";
            //Refresh list of existing functions
            $data_user = $db->fetch_row("SELECT groupes_interdits FROM ".$pre."users WHERE id = ".$_POST['id']);
            $user = explode(';',$data_user[0]);
            
            require_once ("NestedTree.class.php");
            $tree = new NestedTree($pre.'nested_tree', 'id', 'parent_id', 'title');
            $tree_desc = $tree->getDescendants();
            foreach($tree_desc as $t){
                if ( in_array($t->id,$_SESSION['groupes_visibles']) ) {
                    $text .= '<input type=\"checkbox\" id=\"cb_change_forgroup-'.$t->id.'\"';
                    $ident="";
                    for($y=1;$y<$t->nlevel;$y++) $ident .= "&nbsp;&nbsp;";
                    if ( in_array($t->id,$user) ) $text .= ' checked';
                    $text .= '>&nbsp;'.$ident.$t->title.'<br />';
                    $prev_level = $t->nlevel;
                }
            }
            
            echo 'document.getElementById("change_user_forgroups_list").innerHTML = "'.$text.'";';
            echo 'document.getElementById("selected_user").value = "'.$_POST['id'].'";';
                        
            //display dialogbox
            echo '$("#change_user_forgroups").dialog("open");';
            echo '$("#div_loading").hide()';  //hide loading div
        break;
        
        case "change_user_forgroups";
            //save data
            $db->query_update(
                "users",
                array(
                    'groupes_interdits' => $_POST['list']
                ),
                "id = ".$_POST['id']
            );
            
            //display information
            $text = "";
            $val = str_replace(';',',',$_POST['list']);
            //Check if POST is empty
            if ( !empty($_POST['list']) ){
                $rows = $db->fetch_all_array("SELECT title,nlevel FROM ".$pre."nested_tree WHERE id IN (".$val.")");
                foreach( $rows as $reccord ){
                    $ident="";
                    for($y=1;$y<$reccord['nlevel'];$y++) $ident .= "&nbsp;&nbsp;";
                    $text .= '<img src=\"includes/images/arrow-000-small.png\" />'.$ident.$reccord['title']."<br />";
                }
            }
            echo 'document.getElementById("list_forgroups_user_'.$_POST['id'].'").innerHTML = "'.$text.'";';
        break;
        
    }
}

## NEW LOGIN FOR USER HAS BEEN DEFINED ##
else if ( !empty($_POST['newlogin']) ){
    $id = explode('_',$_POST['id']);
    $db->query_update(
        "users",
        array(
            'login' => $_POST['newlogin']
        ),
        "id = ".$id[1]
    );
    //Display info
    echo $_POST['newlogin'];
}

## ADMIN FOR USER HAS BEEN DEFINED ##
else if ( isset($_POST['newadmin']) ){
    $id = explode('_',$_POST['id']);
    $db->query_update(
        "users",
        array(
            'admin' => $_POST['newadmin']
        ),
        "id = ".$id[1]
    );
    //Display info
    if (  $_POST['newadmin'] == "1" ) echo "Oui"; else echo "Non";
}
?>
